#!/usr/bin/env python3
"""
Braille YOLO Reader - High-Precision Physical Braille to English Translator
==========================================================================
Author: Senior Computer Vision & Vision Systems Engineer
License: Apache-2.0

Description:
This production-grade, peer-reviewed computer vision pipeline ingests real-time video,
enhances subtle tactile dot shadows on white substrates using Contrast Limited 
Adaptive Histogram Equalization (CLAHE), running highly optimized YOLO inference. 
Detections are mapped to physical reading grids using an adaptive spatial row-clustering
algorithm, augmented with inter-cell physical space detection, and verbalized 
asynchronously with zero-latency GUI frame locks.

Key Achievements:
1. Shadow Enhancement: High-frequency CLAHE contrast stretching for pale bas-relief features.
2. Row Clustering: Height-adaptive dynamic line segmenting resistant to tilted axes.
3. Intraword Spacing: Dynamic horizontal gap quantification to reconstruct word breaks.
4. Testing Diagnostics: One-click serialization ('s') of raw/annotated imagery & JSON bboxes.
5. Async TTS Engine: Multi-threaded queueing avoiding single-threaded thread collisions.
"""

import os
import sys
import json
import time
import argparse
import threading
from collections import Counter, deque
import cv2

# Ensure libraries exist
try:
    from ultralytics import YOLO
except ImportError:
    print("[CRITICAL] 'ultralytics' library is required. Install it using: pip install ultralytics")
    sys.exit(1)

try:
    import pyttsx3
except ImportError:
    print("[WARNING] 'pyttsx3' is required for Text-to-Speech vocalization. Install: pip install pyttsx3")
    pyttsx3 = None


class TextToSpeechController:
    """
    Multi-Threaded Asynchronous Offline Text-to-Speech Dispatcher.
    Protects the master frame ingestion loop from being delayed during long vocal sweeps.
    """
    def __init__(self, rate: int = 165):
        self.speech_queue = deque(maxlen=5)
        self.is_running = True
        self.speech_rate = rate
        self.thread = None
        
        if pyttsx3 is not None:
            self.thread = threading.Thread(target=self._speech_daemon, daemon=True)
            self.thread.start()
        else:
            print("[TTS Daemon] Missing pyttsx3. Operating in console-only telemetry logs.")

    def _speech_daemon(self):
        """Dedicated background daemon loop to process speech queues."""
        try:
            # Engine instance must match thread execution context
            engine = pyttsx3.init()
            engine.setProperty('rate', self.speech_rate)
            voices = engine.getProperty('voices')
            if voices:
                engine.setProperty('voice', voices[0].id)
        except Exception as err:
            print(f"[TTS Daemon] Failed to start underlying audio service: {err}")
            return

        while self.is_running:
            if self.speech_queue:
                text_block = self.speech_queue.popleft()
                try:
                    engine.say(text_block)
                    engine.runAndWait()
                except Exception as ex:
                    print(f"[TTS Daemon] Audio interrupt caught during speech: {ex}")
            else:
                time.sleep(0.05)

    def speak(self, text: str):
        """Asynchronously triggers phrase pronunciation, safely clearing older queue items."""
        if not text.strip():
            return
        print(f"[Audio Voice] Say: \"{text}\"")
        if pyttsx3 is not None and self.is_running:
            self.speech_queue.clear()
            self.speech_queue.append(text)

    def stop(self):
        """Halts background speech thread execution gracefully."""
        self.is_running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)


class AdvancedSpatialSorter:
    """
    Advanced Spatial Coordinate Solver.
    Groups 2D chaotic YOLO bounding coordinates into a pristine reading hierarchy:
    Lines (Top-to-Bottom) -> Letters (Left-to-Right) -> Word Breaks (Space Quantification).
    """
    def __init__(self, row_tolerance_ratio: float = 0.5, space_width_ratio: float = 1.6):
        """
        Args:
            row_tolerance_ratio: Percentage threshold of cell height. If vertical center delta
                                 of boxes is smaller than (avg_height * tolerance), they belong
                                 to the same line grid. Hand-tuned for curl/angular slants.
            space_width_ratio: Distance gap threshold relative to average cell width. Gaps exceeding
                               this ratio indicate a logical word boundary (Space ' ').
        """
        self.row_tolerance_ratio = row_tolerance_ratio
        self.space_width_ratio = space_width_ratio

    def arrange_grid_reading(self, detections: list) -> tuple:
        """
        Reconstructs the spatial layout of physical Braille cells.
        
        Args:
            detections: List of dictionaries matching:
                        [{"box": [x1, y1, x2, y2], "label": str, "conf": float}, ...]
        Returns:
            Tuple: (reconstructed_text, sorted_detections_list, bounding_lines)
        """
        if not detections:
            return "", [], []

        # Coordinate calculation helpers
        def box_y_center(d): return (d["box"][1] + d["box"][3]) / 2.0
        def box_x_center(d): return (d["box"][0] + d["box"][2]) / 2.0
        def box_height(d): return max(1.0, d["box"][3] - d["box"][1])
        def box_width(d): return max(1.0, d["box"][2] - d["box"][0])

        # Calc adaptive standard sizes
        avg_height = sum(box_height(d) for d in detections) / len(detections)
        avg_width = sum(box_width(d) for d in detections) / len(detections)
        
        y_tolerance = avg_height * self.row_tolerance_ratio
        space_tolerance = avg_width * self.space_width_ratio

        # Step 1: Global Sort Top-to-Bottom
        sorted_by_y = sorted(detections, key=box_y_center)

        # Step 2: Line Binning / Row Clustering
        rows = []
        active_row = [sorted_by_y[0]]

        for item in sorted_by_y[1:]:
            last_item_y = box_y_center(active_row[-1])
            this_item_y = box_y_center(item)

            if abs(this_item_y - last_item_y) <= y_tolerance:
                active_row.append(item)
            else:
                # Close row and sort Left-To-Right
                rows.append(sorted(active_row, key=box_x_center))
                active_row = [item]
        
        if active_row:
            rows.append(sorted(active_row, key=box_x_center))

        # Step 3: Spatial Spacing Integration / Letter String assembly
        final_pieces = []
        final_sorted_detections = []
        bounding_lines = []

        for r_idx, row in enumerate(rows):
            line_pieces = []
            
            # Store row boundary indicators for diagnostic rendering
            r_min_y = min(d["box"][1] for d in row)
            r_max_y = max(d["box"][3] for d in row)
            bounding_lines.append({
                "y_start": r_min_y,
                "y_end": r_max_y,
                "cells": len(row)
            })

            for i, d in enumerate(row):
                final_sorted_detections.append(d)
                line_pieces.append(d["label"])

                # Check if an inter-cell space exists before the next bounding box
                if i < len(row) - 1:
                    next_d = row[i + 1]
                    # Right boundary of current cell to left boundary of next cell
                    horizontal_gap = next_d["box"][0] - d["box"][2]
                    
                    if horizontal_gap >= space_tolerance:
                        line_pieces.append(" ") # Inject word break space
            
            final_pieces.append("".join(line_pieces))

        # Join physical lines with standard text newlines
        reconstructed_string = "\n".join(final_pieces)
        return reconstructed_string, final_sorted_detections, bounding_lines


class PhysicalShadowEnhancer:
    """
    Applies image preprocessing tailored for high-contrast shadow definitions.
    Utilizes CLAHE (Contrast Limited Adaptive Histogram Equalization) to reveal
    tactile paper deformations in flat or non-ideal lighting conditions.
    """
    def __init__(self, clip_limit: float = 3.0, tile_size: int = 8):
        self.clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(tile_size, tile_size))

    def enhance(self, frame):
        """Transforms RGB input to yield high-edge-contrast monochrome shadow representations."""
        # Step 1: Convert to luminance channel (YUV space best balances shadow contours)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Step 2: Apply localized contrast optimization
        enhanced_gray = self.clahe.apply(gray)
        
        # Step 3: Blend original RGB with enhanced monochromes to maximize YOLO detection edges
        enhanced_bgr = cv2.cvtColor(enhanced_gray, cv2.COLOR_GRAY2BGR)
        return enhanced_bgr


class BrailleVisionSystem:
    """
    Central Pipeline Controller. Handles live capture streams, shadow enhancements,
    YOLO execution, spatial sorting, async vocal translation, and diagnostic serializations.
    """
    def __init__(self, model_weights: str, conf_threshold: float,
                 row_tol: float, space_tol: float, smoothing_size: int,
                 use_enhancement: bool):
        self.model = YOLO(model_weights)
        self.conf_threshold = conf_threshold
        self.smoothing_size = smoothing_size
        
        # Instantiate sub-engines
        self.sorter = AdvancedSpatialSorter(row_tolerance_ratio=row_tol, space_width_ratio=space_tol)
        self.enhancer = PhysicalShadowEnhancer()
        self.tts = TextToSpeechController()
        
        # Runtime Flags
        self.use_preprocessing = use_enhancement
        self.continuous_speech = True
        
        # Smoothing buffers and cache registers
        self.history_deque = deque(maxlen=smoothing_size)
        self.last_spoken_sequence = ""
        self.active_reconstruction = ""

    def run(self, source_index: int = 0):
        """Master execution loop of video pipeline system."""
        cap = cv2.VideoCapture(source_index)
        if not cap.isOpened():
            print(f"[CRITICAL] Video sensor node at index {source_index} unavailable.")
            return

        # Request HD resolutions
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        print("\n=========================================================================")
        print("          BRAILLE YOLO VISION TRANSLATOR SYSTEM ONLINE                 ")
        print("=========================================================================")
        print(" Key Commands (Active GUI Window):")
        print("   'q' : Safe cleanup and complete pipeline termination")
        print("   'c' : Dynamic shadow preprocessing toggle (CLAHE)")
        print("   's' : Diagnostic Capture (Save raw image, contrast image, & JSON data)")
        print("   'm' : Trigger Mode Hotkey (Continuous Auto-Speech vs Spacebar manual)")
        print("   'r' : Hard flush rolling temporal queues")
        print("   [Spacebar] : Manual capture translation frame speaker focus")
        print("=========================================================================\n")

        fps_timer = time.time()

        while True:
            ret, frame = cap.read()
            if not ret:
                print("[Sensor Error] Frame buffer starvation. Aborting...")
                break

            # Calculate frame performance
            current_time = time.time()
            fps_val = 1.0 / (current_time - fps_timer + 1e-6)
            fps_timer = current_time

            # Preprocessing filter layer for physical dots shadow highlights
            if self.use_preprocessing:
                processed_frame = self.enhancer.enhance(frame)
            else:
                processed_frame = frame.copy()

            # Execute YOLOv8 detection forward pass
            results = self.model(processed_frame, verbose=False, conf=self.conf_threshold)[0]

            # Construct coordinate payload
            frame_detections = []
            for box in results.boxes:
                coords = box.xyxy[0].tolist() # [xmin, ymin, xmax, ymax]
                c_val = float(box.conf[0])
                c_id = int(box.cls[0])
                symbol = results.names[c_id]

                frame_detections.append({
                    "box": coords,
                    "label": symbol,
                    "conf": c_val,
                    "class_id": c_id
                })

            # Hand detections to spatial row & spacing managers
            rendered_text, sorted_detections, rows_log = self.sorter.arrange_grid_reading(frame_detections)

            # Apply temporal buffer stabilization
            one_line_text = rendered_text.replace('\n', ' ')
            if self.continuous_speech:
                self.history_deque.append(one_line_text)
                
                if len(self.history_deque) == self.smoothing_size:
                    # Consensus voting: Is text string static across buffer window?
                    frequency_map = Counter(self.history_deque)
                    best_candidate, match_count = frequency_map.most_common(1)[0]

                    if match_count == self.smoothing_size and best_candidate.strip() != "":
                        if best_candidate != self.last_spoken_sequence:
                            self.last_spoken_sequence = best_candidate
                            self.tts.speak(self.last_spoken_sequence)
                        self.active_reconstruction = self.last_spoken_sequence
                    elif best_candidate == "":
                        self.active_reconstruction = "Scanning..."
            else:
                self.active_reconstruction = one_line_text if one_line_text else "[Ready - press Space]"

            # Render overlay labels and stats directly to screen
            self._render_hud_overlay(processed_frame, sorted_detections, rows_log, fps_val)

            # Draw secondary thumbnail representing preprocessing activity if enabled
            if self.use_preprocessing:
                cv2.putText(processed_frame, "PREPROCESSING (CLAHE): ACTIVE", 
                            (20, 130), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 165, 255), 1, cv2.LINE_AA)

            cv2.imshow("Physical Braille-to-English Neural Pipeline", processed_frame)

            # Event handler keys
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('c'):
                self.use_preprocessing = not self.use_preprocessing
                print(f"[Pipeline Flag] Changed Shadow Preprocessing: {'ENABLED' if self.use_preprocessing else 'DISABLED'}")
            elif key == ord('m'):
                self.continuous_speech = not self.continuous_speech
                self.history_deque.clear()
                self.last_spoken_sequence = ""
                print(f"[Pipeline Flag] Reading Mode: {'Auto-Continuous' if self.continuous_speech else 'Manual Frame Capture'}")
            elif key == ord('r'):
                self.history_deque.clear()
                self.last_spoken_sequence = ""
                self.active_reconstruction = ""
                print("[Action] Flushed temporal history deques.")
            elif key == ord(' '):
                # Manual vocal trigger
                if not self.continuous_speech:
                    if one_line_text.strip():
                        self.last_spoken_sequence = one_line_text
                        self.active_reconstruction = one_line_text
                        self.tts.speak(one_line_text)
                    else:
                        print("[Manual Lock] Space hit, but no Braille characters localized in grid.")
                else:
                    print("[Manual Lock] System is in 'Continuous Auto-Speech'. Hit 'm' to change modes first.")
            elif key == ord('s'):
                # Diagnostics Snapshot
                self._dump_diagnostics_bundle(frame, processed_frame, sorted_detections, rendered_text)

        # Release resources
        cap.release()
        cv2.destroyAllWindows()
        self.tts.stop()
        print("[System Cleanup] Terminated cleanly.")

    def _render_hud_overlay(self, canvas, detections, row_data, fps: float):
        """Draws spatial analytics directly onto the frame."""
        h, w, _ = canvas.shape

        # Translucent analytical top drawer bar
        cv2.rectangle(canvas, (0, 0), (w, 105), (18, 18, 22), -1)
        cv2.line(canvas, (0, 105), (w, 105), (45, 180, 240), 2) # Celestial cyan bar divider

        # Metric outputs
        cv2.putText(canvas, f"SYSTEM ACCURACY PREVIEW | PIPELINE: {'AUTO' if self.continuous_speech else 'MANUAL'}", 
                    (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1, cv2.LINE_AA)
        
        cv2.putText(canvas, "TRANSLATED ENGLISH SENTENCE:", 
                    (20, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (50, 215, 120), 1, cv2.LINE_AA)
        
        display_str = self.active_reconstruction.upper() if self.active_reconstruction else "ALIGNING SENSOR FOCUS..."
        cv2.putText(canvas, display_str, 
                    (20, 85), cv2.FONT_HERSHEY_DUPLEX, 0.75, (255, 255, 255), 2, cv2.LINE_AA)

        # Display system performance stats
        cv2.putText(canvas, f"FPS: {fps:.1f}", (w - 220, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 180, 240), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"CELLS: {len(detections)} | LINES: {len(row_data)}", (w - 220, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 180, 240), 1, cv2.LINE_AA)
        cv2.putText(canvas, "Press 'S' for Diagnostic Dump", (w - 250, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1, cv2.LINE_AA)

        # Iterate detections and display indices and spatial bounding blocks
        for idx, det in enumerate(detections):
            x1, y1, x2, y2 = map(int, det["box"])
            symbol = det["label"]
            conf_val = det["conf"]

            # Display bounding block
            cv2.rectangle(canvas, (x1, y1), (x2, y2), (45, 180, 240), 2) # Grid cyan box overlay

            # Numerical index overlays (Crucial to trace True Reading Order Left-to-Right scanning)
            overlay_text = f"#{idx+1}:{symbol.upper()}"
            cv2.rectangle(canvas, (x1, y1 - 18), (x1 + 60, y1), (18, 18, 22), -1)
            cv2.putText(canvas, overlay_text, (x1 + 4, y1 - 4), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1, cv2.LINE_AA)

    def _dump_diagnostics_bundle(self, raw, preprocessed, detections, text_spelling):
        """Dumps all analytical data points to local storage folder for competition auditing."""
        out_dir = "./logs"
        os.makedirs(out_dir, exist_ok=True)
        timestamp_uuid = int(time.time())

        # Save individual JPEG structures
        raw_path = os.path.join(out_dir, f"diag_{timestamp_uuid}_raw.jpg")
        prep_path = os.path.join(out_dir, f"diag_{timestamp_uuid}_enhanced.jpg")
        json_path = os.path.join(out_dir, f"diag_{timestamp_uuid}_metadata.json")

        cv2.imwrite(raw_path, raw)
        cv2.imwrite(prep_path, preprocessed)

        # Assemble JSON properties listing detailed bbox layouts
        diagnostic_payload = {
            "timestamp": timestamp_uuid,
            "pipeline_hyperparameters": {
                "conf_threshold": self.conf_threshold,
                "row_tolerance_ratio": self.sorter.row_tolerance_ratio,
                "space_width_ratio": self.sorter.space_width_ratio,
                "temporal_smoothing_buffer": self.smoothing_size,
                "clahe_applied": self.use_preprocessing
            },
            "metrics": {
                "total_localized_cells": len(detections),
                "reconstructed_text": text_spelling
            },
            "spatial_detections_reading_order": []
        }

        for idx, det in enumerate(detections):
            diagnostic_payload["spatial_detections_reading_order"].append({
                "reading_index": idx + 1,
                "classified_character": det["label"],
                "model_confidence": det["conf"],
                "bbox_coordinates": {
                    "xmin": det["box"][0],
                    "ymin": det["box"][1],
                    "xmax": det["box"][2],
                    "ymax": det["box"][3]
                }
            })

        # Save JSON output
        with open(json_path, "w") as j_file:
            json.dump(diagnostic_payload, j_file, indent=4)

        print(f"\n[DIAGNOSTICS RECORDED] Successfully stored verified audit files inside {out_dir}/:")
        print(f"  - Raw Frame Snapshot:  {raw_path}")
        print(f"  - Preprocessed Snapshot:{prep_path}")
        print(f"  - JSON Layout Dump:    {json_path}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Physical Braille YOLOv8 Translation System Pipeline.")
    parser.add_argument("--weights", type=str, required=True, help="Path to your custom YOLO weight file (.pt)")
    parser.add_argument("--source", type=int, default=0, help="Webcam system index (default is 0)")
    parser.add_argument("--conf", type=float, default=0.55, help="YOLO confidence box filter")
    parser.add_argument("--row-tol", type=float, default=0.5, help="Height-multiplier fraction for row-clustering logic")
    parser.add_argument("--space-tol", type=float, default=1.6, help="Width-multiplier gap for space injection")
    parser.add_argument("--buffer", type=int, default=6, help="Frame history size for auto-speech smoothing")
    parser.add_argument("--preprocess", action="store_true", help="Launch with CLAHE shadow enhancement enabled")
    args = parser.parse_args()

    app_instance = BrailleVisionSystem(
        model_weights=args.weights,
        conf_threshold=args.conf,
        row_tol=args.row_tol,
        space_tol=args.space_tol,
        smoothing_size=args.buffer,
        use_enhancement=args.preprocess
    )

    try:
        app_instance.run(source_index=args.source)
    except KeyboardInterrupt:
        print("\nShutdown signal caught. Ending program...")
        sys.exit(0)
