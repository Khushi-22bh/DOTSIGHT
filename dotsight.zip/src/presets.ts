/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Preset } from './types';

export const SIMULATION_PRESETS: Preset[] = [
  {
    id: 'hello-world',
    name: 'Multi-Line Greeting ("hello world")',
    description: 'Two neat, distinct rows. Shows standard multi-line sorting where Y-centers separate clearly.',
    cells: [
      // Row 1: "hello" at Y-centers around 100
      { x: 100, y: 95, width: 44, height: 60, letter: 'h' },
      // YOLO outputs cells in arbitary order, so we mix up the arrays to test the sorting engine!
      { x: 380, y: 102, width: 42, height: 58, letter: 'o' },
      { x: 170, y: 105, width: 45, height: 62, letter: 'e' },
      { x: 310, y: 98, width: 43, height: 60, letter: 'l' },
      { x: 240, y: 95, width: 42, height: 61, letter: 'l' },

      // Row 2: "world" at Y-centers around 240
      { x: 120, y: 245, width: 44, height: 60, letter: 'w' },
      { x: 400, y: 238, width: 45, height: 61, letter: 'd' },
      { x: 190, y: 239, width: 42, height: 58, letter: 'o' },
      { x: 330, y: 244, width: 43, height: 59, letter: 'l' },
      { x: 260, y: 250, width: 44, height: 62, letter: 'r' }
    ]
  },
  {
    id: 'intraword-demo',
    name: 'Intraword Spacing ("go yolo")',
    description: 'A single line containing a physical gap between "go" and "yolo". Try moving the Space Width Ratio slider to watch spaces toggle live!',
    cells: [
      { x: 100, y: 150, width: 44, height: 60, letter: 'g' },
      { x: 160, y: 152, width: 44, height: 60, letter: 'o' },
      // Wide horizontal gap: gap goes from X=204 to X=350 (146px gap, which is ~3.3x cell width)
      { x: 350, y: 148, width: 44, height: 60, letter: 'y' },
      { x: 410, y: 151, width: 44, height: 60, letter: 'o' },
      { x: 470, y: 149, width: 44, height: 60, letter: 'l' },
      { x: 530, y: 153, width: 44, height: 60, letter: 'o' }
    ]
  },
  {
    id: 'skewed-alignment',
    name: 'Tilted / Jagged Row ("braille")',
    description: 'A single text line scanned with a tilted camera or uneven printing. Requires helper tolerance ratio adjustments (e.g. >= 0.5) to keep letters in one row.',
    cells: [
      { x: 80, y: 130, width: 46, height: 62, letter: 'b' },
      { x: 150, y: 142, width: 44, height: 60, letter: 'r' },
      { x: 220, y: 155, width: 45, height: 63, letter: 'a' },
      { x: 290, y: 168, width: 43, height: 59, letter: 'i' },
      { x: 360, y: 180, width: 45, height: 61, letter: 'l' },
      { x: 430, y: 192, width: 44, height: 60, letter: 'l' },
      { x: 500, y: 205, width: 43, height: 62, letter: 'e' }
    ]
  },
  {
    id: 'overlapping-edge',
    name: 'Complex Density ("yolo reader")',
    description: 'Multiple lines with irregular spaces, staggered offsets, and varying cell heights. Tests the flexibility of the sorting engine.',
    cells: [
      // Row 1: "yolo"
      { x: 150, y: 110, width: 45, height: 65, letter: 'y' },
      { x: 370, y: 95, width: 40, height: 55, letter: 'o' },
      { x: 290, y: 115, width: 44, height: 64, letter: 'l' },
      { x: 220, y: 100, width: 42, height: 60, letter: 'o' },

      // Row 2: "reader" with slightly misaligned Y coordinates
      { x: 100, y: 260, width: 45, height: 60, letter: 'r' },
      { x: 170, y: 245, width: 42, height: 58, letter: 'e' },
      { x: 240, y: 275, width: 44, height: 65, letter: 'a' },
      { x: 310, y: 255, width: 43, height: 60, letter: 'd' },
      { x: 385, y: 270, width: 42, height: 62, letter: 'e' },
      { x: 460, y: 250, width: 45, height: 59, letter: 'r' }
    ]
  }
];
