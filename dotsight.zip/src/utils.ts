/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrailleCell, BoundingRow } from './types';

/**
 * TypeScript Implementation of our Spatial Sorting Engine
 * Matches the logic from our python script braille_translator.py exactly
 */
export function sortBrailleCells(
  cells: BrailleCell[],
  toleranceRatio: number,
  spaceWidthRatio: number
): { sortedCells: BrailleCell[]; boundingRows: BoundingRow[]; reconstructedText: string } {
  if (cells.length === 0) {
    return { sortedCells: [], boundingRows: [], reconstructedText: '' };
  }

  // Helper getters matching Python bboxes midpoints
  const getXCenter = (c: BrailleCell) => c.x + c.width / 2.0;
  const getYCenter = (c: BrailleCell) => c.y + c.height / 2.0;

  // Calculate standard reference height of a cell
  const heights = cells.map((c) => c.height);
  const avgHeight = heights.reduce((sum, h) => sum + h, 0) / cells.length;
  const rowTolerance = avgHeight * toleranceRatio;

  // Calculate reference average width for spacing detection
  const widths = cells.map((c) => c.width);
  const avgWidth = widths.reduce((sum, w) => sum + w, 0) / cells.length;
  const spaceTolerance = avgWidth * spaceWidthRatio;

  // Step 1: Sort globally by Y-center (Top-to-Bottom scan order)
  const sortedByY = [...cells].sort((a, b) => getYCenter(a) - getYCenter(b));

  // Step 2: Bin cells into rows based on vertical proximity
  const rows: BrailleCell[][] = [];
  let currentRow: BrailleCell[] = [sortedByY[0]];

  for (let i = 1; i < sortedByY.length; i++) {
    const currentCell = sortedByY[i];
    const lastCellInRow = currentRow[currentRow.length - 1];

    const lastY = getYCenter(lastCellInRow);
    const thisY = getYCenter(currentCell);

    // If within our height tolerance delta, they belong on the same line
    if (Math.abs(thisY - lastY) <= rowTolerance) {
      currentRow.push(currentCell);
    } else {
      // Sort preceding row left-to-right (horizontal realignment)
      rows.push([...currentRow].sort((a, b) => getXCenter(a) - getXCenter(b)));
      currentRow = [currentCell];
    }
  }

  // Append remaining items
  if (currentRow.length > 0) {
    rows.push([...currentRow].sort((a, b) => getXCenter(a) - getXCenter(b)));
  }

  // Flatten rows to yield raw sequence list, and compile BoundingRow segments
  const sortedCells: BrailleCell[] = [];
  const boundingRows: BoundingRow[] = [];
  const lineTexts: string[] = [];

  rows.forEach((rowCells) => {
    sortedCells.push(...rowCells);

    const yMin = Math.min(...rowCells.map((c) => c.y));
    const yMax = Math.max(...rowCells.map((c) => c.y + c.height));

    boundingRows.push({
      yCenterStart: yMin,
      yCenterEnd: yMax,
      cells: rowCells
    });

    // Spacing Integration for this specific row
    const rowCharacters: string[] = [];
    for (let cIdx = 0; cIdx < rowCells.length; cIdx++) {
      const cell = rowCells[cIdx];
      rowCharacters.push(cell.letter);

      // Check if an inter-cell space exists before the next bounding box
      if (cIdx < rowCells.length - 1) {
        const nextCell = rowCells[cIdx + 1];
        // Right edge of current cell to left edge of next cell
        const gap = nextCell.x - (cell.x + cell.width);
        
        if (gap >= spaceTolerance) {
          rowCharacters.push(' ');
        }
      }
    }
    lineTexts.push(rowCharacters.join(''));
  });

  const reconstructedText = lineTexts.join('\n');

  return { sortedCells, boundingRows, reconstructedText };
}
