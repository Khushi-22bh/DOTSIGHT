/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BrailleCell {
  id: string;
  x: number; // Percentage or pixels relative to a standard canvas coordinate (e.g., 0-800 for width)
  y: number; // Relative coordinate (e.g., 0-450 for height)
  width: number;
  height: number;
  letter: string;
}

export interface BoundingRow {
  yCenterStart: number;
  yCenterEnd: number;
  cells: BrailleCell[];
}

export type PipelineMode = 'continuous' | 'manual';

export interface SimulatorConfig {
  rowToleranceRatio: number; // float representing percentage of average cell-height (0.1 to 1.5)
  spaceWidthRatio: number; // float representing ratio of average cell-width to inject spaces (1.0 to 3.0)
  claheEnabled: boolean; // boolean representing CLAHE shadow preprocessing
  smoothingWindow: number; // 2 to 15 frames
  noiseChance: number; // percentage (0% to 50%) of letters flickering on random frames
  detectionFPS: number; // speed of the virtual camera loop rate
}

export interface Preset {
  id: string;
  name: string;
  description: string;
  cells: Omit<BrailleCell, 'id'>[];
}
