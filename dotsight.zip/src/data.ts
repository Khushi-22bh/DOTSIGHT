/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const PYTHON_CODE_STRING = `#!/usr/bin/env python3
"""
Braille YOLO Reader - Real-Time Physical Braille to English Translator
======================================================================
Author: Senior Computer Vision and Python Developer
License: Apache-2.0

Description:
This production-grade script captures real-time video, runs a custom YOLO model loaded via
Ultralytics, clusters/sorts detected Braille cells in true reading order (Top-to-Bottom, Left-to-Right),
applies temporal smoothing to debounce flickering frame predictions, and pronounces translations
asynchronously using a local, offline Text-to-Speech engine (pyttsx3).

Requirements:
    pip install opencv-python ultralytics pyttsx3

Usage:
    python braille_translator.py --weights path/to/your/custom_yolo.pt
"""

import argparse
import sys
import threading
import time
from collections import Counter, deque
import cv2

try:
    from ultralytics import YOLO
except ImportError:
    print("[Error] 'ultralytics' library is required. Install it using: pip install ultralytics")
    sys.exit(1)

try:
    import pyttsx3
except ImportError:
    print("[Warning] 'pyttsx3' is required for Text-to-Speech. Install it using: pip install pyttsx3")
    pyttsx3 = None


class TextToSpeechEngine:
    """
    Asynchronous Offline Text-to-Speech wrapper utilizing pyttsx3.
    Ensures TTS execution runs on a distinct background thread to prevent
    blocking the primary OpenCV video ingestion and inference pipeline.
    """
    def __init__(self):
        self.speech_queue = deque(maxlen=5)
        self.is_running = True
        self.tts_thread = None
        
        if pyttsx3 is not None:
            # Initialize TTS on background thread to avoid CoInitialize issues in Windows
            self.tts_thread = threading.Thread(target=self._speech_worker, daemon=True)
            self.tts_thread.start()
        else:
            print("[TTS Engine] Running in dummy/silent mode because pyttsx3 is not installed.")

    def _speech_worker(self):
        """Background thread worker to initialize and run the pyttsx3 event loop."""
        try:
            # Engine initialization must occur in the thread that uses it
            engine = pyttsx3.init()
            # Opt for a natural talking speed (default is usually ~200)
            engine.setProperty('rate', 165)
            # Find and set an elegant voice if available
            voices = engine.getProperty('voices')
            if voices:
                engine.setProperty('voice', voices[0].id)
        except Exception as e:
            print(f"[TTS Engine] Initialization failed: {e}. Falling back to terminal log output.")
            return

        while self.is_running:
            if self.speech_queue:
                text = self.speech_queue.popleft()
                try:
                    engine.say(text)
                    engine.runAndWait()
                except Exception as ex:
                    print(f"[TTS Engine] Error pronouncing text: {ex}")
            else:
                time.sleep(0.05)

    def speak(self, text: str):
        """Queues a text phrase for async playback."""
        if not text.strip():
            return
        print(f"[Speech Trigger] Pronouncing: '{text}'")
        if pyttsx3 is not None and self.is_running:
            # Clear previous backlog to avoid reading stale frames
            self.speech_queue.clear()
            self.speech_queue.append(text)

    def stop(self):
        """Gracefully halts the TTS background thread."""
        self.is_running = False
        if self.tts_thread and self.tts_thread.is_alive():
            self.tts_thread.join(timeout=1.0)


class SpatialSortingEngine:
    """
    Interprets independent YOLO 2D bounding boxes and translates them into a cohesive 
    reading grid (left-to-right, line-by-line).
    
    YOLO operates probabilistically and returns bbox detections in arbitrary confidence orders.
    This translation engine clusters cells into lines using a adaptive vertical distance tolerance.
    """
    def __init__(self, tolerance_ratio: float = 0.5):
        """
        Args:
            tolerance_ratio: Ratio relative to cell height. If the vertical distance between the
                             centers of two cells is smaller than (cell_height * tolerance_ratio),
                             the cells are classified as being on the same line/row.
        """
        self.tolerance_ratio = tolerance_ratio

    def arrange_reading_order(self, detections: list) -> list:
        """
        Sorts bounding boxes into a linear sequence scanning Top-to-Bottom, Left-to-Right.
        
        Expects a list of dicts:
            [{"box": [x1, y1, x2, y2], "label": str, "conf": float}, ...]
        """
        if not detections:
            return []

        # Functions to extract spatial dimensions of the bounding boxes
        def get_y_center(d):
            return (d["box"][1] + d["box"][3]) / 2.0

        def get_x_center(d):
            return (d["box"][0] + d["box"][2]) / 2.0

        def get_height(d):
            return max(1.0, d["box"][3] - d["box"][1])

        # Calculate a robust reference height using the average height of all detected cells.
        # This allows the thresholds to scale adaptively if the camera zooms in or out.
        avg_height = sum(get_height(d) for d in detections) / len(detections)
        row_tolerance = avg_height * self.tolerance_ratio

        # Step 1: Sort globally by Y-center. This ranks cells roughly top-to-bottom.
        sorted_by_y = sorted(detections, key=get_y_center)

        # Step 2: Group boxes into distinct horizontal lines / rows
        rows = []
        current_row = [sorted_by_y[0]]

        for cell in sorted_by_y[1:]:
            last_cell_y = get_y_center(current_row[-1])
            cell_y = get_y_center(cell)

            # If the difference in midpoints is within tolerance, append to the active row
            if abs(cell_y - last_cell_y) <= row_tolerance:
                current_row.append(cell)
            else:
                # The cell belongs to a new line. Sort the finished row horizontally (Left-to-Right)
                sorted_row = sorted(current_row, key=get_x_center)
                rows.append(sorted_row)
                current_row = [cell]

        # Sort and append the final remaining row
        if current_row:
            sorted_row = sorted(current_row, key=get_x_center)
            rows.append(sorted_row)

        # Step 3: Flatten rows back into a single ordered reading array
        sorted_detections = []
        for r in rows:
            sorted_detections.extend(r)

        return sorted_detections


class BrailleYOLOReader:
    """
    Core pipeline manager. Reconciles OpenCV video capture, model execution,
    spatial sorting, sequential text reconstruction, debouncing, HUD rendering, and speech.
    """
    def __init__(self, model_path: str, confidence_thresh: float = 0.5, 
                 smoothing_window: int = 8, continuous_mode: bool = True):
        """
        Args:
            model_path: Absolute or relative path to the YOLO .pt weights.
            confidence_thresh: Confidence score filter for YOLO predictions.
            smoothing_window: Count of consecutive frames a prediction string must remain
                              completely static and identical to be emitted in Continuous Mode.
            continuous_mode: If True, tracks stabilization in continuous frames.
                             If False, translation outputs are locked until pressing the 'Spacebar' trigger.
        """
        print("[Pipeline Engine] Initializing custom YOLO model...")
        self.model = YOLO(model_path)
        self.confidence_thresh = confidence_thresh
        self.sorter = SpatialSortingEngine(tolerance_ratio=0.5)
        self.tts = TextToSpeechEngine()
        
        # Temporal smoothing buffers
        self.continuous_mode = continuous_mode
        self.smoothing_window = smoothing_window
        self.frame_buffer = deque(maxlen=smoothing_window)
        self.last_finalized_text = ""
        self.active_display_text = ""

    def run(self, camera_index: int = 0):
        """Starts the video loop."""
        cap = cv2.VideoCapture(camera_index)
        if not cap.isOpened():
            print(f"[Error] Could not initialize webcam at index {camera_index}")
            return

        # Configure ideal video parameters for high-definition frame grabbing
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        print("\\n=== SYSTEM ONLINE ===")
        print("  Controls:")
        print("    'q'     : Quit and release resources")
        print("    'space' : Translate & speak current stabilized frame (Manual Trigger)")
        print("    'm'     : Toggle pipeline modes (Continuous vs Space-Triggered)")
        print("    'r'     : Force clear temporal buffers")
        print("======================\\n")

        fps_prev_time = time.time()
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[Error] Failed to read frame from sensor.")
                break

            h, w, _ = frame.shape
            current_time = time.time()
            fps = 1.0 / (current_time - fps_prev_time + 1e-6)
            fps_prev_time = current_time

            # Perform inference with spatial bounding boxes and class indexes
            results = self.model(frame, verbose=False, conf=self.confidence_thresh)[0]

            # Aggregate detection attributes
            raw_detections = []
            for box in results.boxes:
                coords = box.xyxy[0].tolist()  # [x1, y1, x2, y2]
                conf = float(box.conf[0])
                class_id = int(box.cls[0])
                label = results.names[class_id]

                raw_detections.append({
                    "box": coords,
                    "label": label,
                    "conf": conf,
                    "cls": class_id
                })

            # Pass detections down the Spatial Sorting engine to reconstruct the sequence
            sorted_detections = self.sorter.arrange_reading_order(raw_detections)
            reconstructed_text = "".join([d["label"] for d in sorted_detections])

            # Apply temporal smoothing / debouncing
            if self.continuous_mode:
                self.frame_buffer.append(reconstructed_text)
                if len(self.frame_buffer) == self.smoothing_window:
                    consensus_counter = Counter(self.frame_buffer)
                    most_common_text, occurrences = consensus_counter.most_common(1)[0]
                    
                    if occurrences == self.smoothing_window and most_common_text != "":
                        if most_common_text != self.last_finalized_text:
                            self.last_finalized_text = most_common_text
                            self.tts.speak(self.last_finalized_text)
                        self.active_display_text = self.last_finalized_text
                    elif most_common_text == "":
                        self.active_display_text = "Scanning Braille..."
            else:
                self.active_display_text = reconstructed_text if reconstructed_text else "Press 'Space' to Translate"

            # Draw visual guidance boundaries and parsed text HUD layout
            self._render_hud(frame, sorted_detections, fps)

            # Display window frame
            cv2.imshow("Physical Braille-to-English Reader", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord(' '):  # Spacebar Manual Trigger
                if not self.continuous_mode:
                    if reconstructed_text:
                        self.last_finalized_text = reconstructed_text
                        self.active_display_text = reconstructed_text
                        self.tts.speak(reconstructed_text)
                    else:
                        print("[Manual Trigger] No Braille cells detected to speak.")
                else:
                    print("[Manual Trigger] System is in 'Continuous' mode. Press 'm' to switch.")
            elif key == ord('m'):  # Toggle Modes
                self.continuous_mode = not self.continuous_mode
                self.frame_buffer.clear()
                self.last_finalized_text = ""
                print(f"[Config Update] Switched to {'Continuous' if self.continuous_mode else 'Manual Spacebar Trigger'} Mode.")
            elif key == ord('r'):  # Reset
                self.frame_buffer.clear()
                self.last_finalized_text = ""
                self.active_display_text = ""
                print("[Action] Cleared buffers and reset translation.")

        cap.release()
        cv2.destroyAllWindows()
        self.tts.stop()
        print("[Pipeline Engine] Stopped gracefully.")

    def _render_hud(self, frame, sorted_detections, fps: float):
        """Draws professional analytical HUD elements, bounds, and sorted reading sequences."""
        h, w, _ = frame.shape

        cv2.rectangle(frame, (0, 0), (w, 100), (20, 20, 24), -1)
        cv2.line(frame, (0, 100), (w, 100), (145, 120, 90), 2)  # Amber divider

        mode_text = f"MODE: {'CONTINUOUS (AUTO-SPEECH)' if self.continuous_mode else 'MANUAL (SPACEBAR CAPTURE)'}"
        cv2.putText(frame, mode_text, (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (180, 180, 180), 1, cv2.LINE_AA)

        target_display_text = self.active_display_text if self.active_display_text else "Aligning camera with Braille..."
        cv2.putText(frame, "RECONSTRUCTED ENGLISH TEXT:", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 220, 120), 1, cv2.LINE_AA)
        cv2.putText(frame, target_display_text.upper(), (20, 88), cv2.FONT_HERSHEY_DUPLEX, 0.75, (255, 255, 255), 2, cv2.LINE_AA)

        stats_text = f"FPS: {fps:.1f} | Cells: {len(sorted_detections)}"
        cv2.putText(frame, stats_text, (w - 220, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 180, 240), 1, cv2.LINE_AA)
        cv2.putText(frame, "Press 'Q' to Exit", (w - 150, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (100, 100, 100), 1, cv2.LINE_AA)

        for idx, det in enumerate(sorted_detections):
            x1, y1, x2, y2 = map(int, det["box"])
            label = det["label"]
            conf = det["conf"]

            color = (0, 255, 120)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

            idx_label = f"#{idx + 1}"
            cv2.rectangle(frame, (x1, y1 - 22), (x1 + 65, y1), (20, 20, 24), -1)
            cv2.putText(frame, f"{idx_label}:{label.upper()}", (x1 + 3, y1 - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Real-Time Braille to English translation pipeline.")
    parser.add_argument("--weights", type=str, required=True, help="Path to custom YOLO .pt weights file")
    parser.add_argument("--conf", type=float, default=0.55, help="YOLO confidence score cutoff threshold")
    parser.add_argument("--buffer", type=int, default=8, help="Count of stable frames required to speak in continuous mode")
    parser.add_argument("--manual", action="store_true", help="Launch in manual spacebar trigger mode instead of continuous")
    args = parser.parse_args()

    app = BrailleYOLOReader(
        model_path=args.weights,
        confidence_thresh=args.conf,
        smoothing_window=args.buffer,
        continuous_mode=not args.manual
    )

    try:
        app.run(camera_index=0)
    except KeyboardInterrupt:
        print("\\n[User Interrupt] Force shutdown signal captured. Cleaning up and exiting...")
        sys.exit(0)
`;
