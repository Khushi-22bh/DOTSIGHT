/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, HelpCircle, Sliders, ToggleLeft, ToggleRight, Sparkles, Save, Eye } from 'lucide-react';
import { PipelineMode, SimulatorConfig } from '../types';

interface SmoothingVisualizerProps {
  currentFrameText: string;
  config: SimulatorConfig;
  onChangeConfig: (newConfig: SimulatorConfig) => void;
  pipelineMode: PipelineMode;
  onTogglePipelineMode: () => void;
  onSpeak: (text: string) => void;
}

export default function SmoothingVisualizer({
  currentFrameText,
  config,
  onChangeConfig,
  pipelineMode,
  onTogglePipelineMode,
  onSpeak
}: SmoothingVisualizerProps) {
  // Mock rolling frame history buffer state to visualize temporal smoothing
  const [frameHistory, setFrameHistory] = useState<string[]>([]);
  const [stableText, setStableText] = useState<string>('');
  const [isSimulatingFeed, setIsSimulatingFeed] = useState<boolean>(true);
  const [flickerActive, setFlickerActive] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [showTuningOptions, setShowTuningOptions] = useState<boolean>(false);

  // Virtual Frame ingestion camera clock
  useEffect(() => {
    if (!isSimulatingFeed) return;

    const interval = setInterval(() => {
      // Determine what sequence this frame produces
      let frameOutput = currentFrameText;

      // Simulate a random letter dropout or noise glitch based on the noiseChance slider
      const rollNoise = Math.random() < config.noiseChance / 100;
      if (rollNoise && currentFrameText.length > 0) {
        setFlickerActive(true);
        setTimeout(() => setFlickerActive(false), 150);

        // Mutate a letter or slice the string to simulate YOLO flicker
        const charToChange = Math.floor(Math.random() * currentFrameText.length);
        const chars = currentFrameText.split('');
        
        // Randomly drop, swap with random letter, or skip
        const noiseType = Math.random();
        if (noiseType < 0.4) {
          // Drop character
          chars.splice(charToChange, 1);
        } else {
          // Mutate to an arbitrary character
          chars[charToChange] = '?';
        }
        frameOutput = chars.join('');
      }

      // Add to frame history queues (behaving as a bounded deque)
      setFrameHistory((prev) => {
        const next = [...prev, frameOutput];
        if (next.length > config.smoothingWindow) {
          next.shift();
        }
        return next;
      });
    }, 1000 / config.detectionFPS);

    return () => clearInterval(interval);
  }, [currentFrameText, isSimulatingFeed, config.detectionFPS, config.noiseChance, config.smoothingWindow]);

  // Read current history queues and decide consensus
  useEffect(() => {
    if (frameHistory.length === 0) return;

    // In continuous mode, the consensus rule:
    // Every single frame in the active bounding window must match exactly, and cannot be empty
    if (pipelineMode === 'continuous') {
      const allIdentical = frameHistory.length === config.smoothingWindow && 
                           frameHistory.every((f) => f === frameHistory[0]);

      if (allIdentical) {
        const consensusText = frameHistory[0];
        if (consensusText && consensusText !== stableText) {
          setStableText(consensusText);
          onSpeak(consensusText);
          
          setIsSpeaking(true);
          setTimeout(() => setIsSpeaking(false), 1200);
        }
      } else if (frameHistory.every(f => f === '')) {
        setStableText('');
      }
    }
  }, [frameHistory, config.smoothingWindow, pipelineMode, stableText, onSpeak]);

  // Force trigger speech manually helper
  const handleTriggerManualSpeech = () => {
    if (currentFrameText) {
      setStableText(currentFrameText);
      onSpeak(currentFrameText);
      setIsSpeaking(true);
      setTimeout(() => setIsSpeaking(false), 1200);
    }
  };

  // Reset buffers
  const handleResetHistory = () => {
    setFrameHistory([]);
    setStableText('');
  };

  // Save diagnostic bundle to local JSON (satisfies Offline Diagnostics)
  const handleSaveDiagnosticLog = () => {
    const payload = {
      timestamp: new Date().toISOString(),
      pipeline_parameters: {
        rowToleranceRatio: config.rowToleranceRatio,
        spaceWidthRatio: config.spaceWidthRatio,
        smoothingWindow: config.smoothingWindow,
        noiseChance: config.noiseChance,
        claheEnabled: config.claheEnabled,
        triggerMode: pipelineMode
      },
      accumulated_buffer: {
        size: frameHistory.length,
        frames: frameHistory
      },
      reconstructed_text: currentFrameText,
      diagnostics_summary: "Physical shadow-enhanced Braille cell coordinates stream completed successfully."
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(payload, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `braille_diagnostics_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // 's' Keyboard trigger (matches Python CLI requirements for Diagnostics saving)
  useEffect(() => {
    const handleSShortcut = (e: KeyboardEvent) => {
      const targetTag = (e.target as HTMLElement)?.tagName || '';
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(targetTag)) return;

      if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        handleSaveDiagnosticLog();
      }
    };
    window.addEventListener('keydown', handleSShortcut);
    return () => window.removeEventListener('keydown', handleSShortcut);
  }, [config, pipelineMode, currentFrameText, frameHistory]);

  return (
    <div id="smoothing-controller-section" className="flex flex-col bg-white border border-slate-200 rounded-xl p-5 shadow-xs gap-5 text-left">
      
      {/* HUD metrics */}
      <div className="flex justify-between items-center border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-sm font-bold text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
            <Volume2 size={16} className="text-sky-600 animate-pulse" />
            Translation & Speech Controller
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Control spatial grouping and temporal speech rules</p>
        </div>
        <button
          id="btn-toggle-engine"
          onClick={() => setIsSimulatingFeed(!isSimulatingFeed)}
          className={`px-3 py-1 text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer transition-all ${
            isSimulatingFeed
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs'
              : 'bg-slate-100 text-slate-500 border border-slate-200 hover:text-slate-800'
          }`}
        >
          {isSimulatingFeed ? <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> : null}
          {isSimulatingFeed ? 'Sim Active' : 'Sim Paused'}
        </button>
      </div>

      {/* Massive Central Vocal & Speech Focus Frame */}
      <div className={`border-2 rounded-2xl p-6 flex flex-col justify-center items-center text-center transition-all duration-300 relative overflow-hidden ${
        isSpeaking 
          ? 'bg-indigo-50/70 border-indigo-500 shadow-[0_0_25px_rgba(99,102,241,0.25)] scale-[1.01]' 
          : 'bg-slate-50/60 border-slate-200 shadow-inner'
      }`}>
        <div className="absolute top-3 right-3 flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${isSpeaking ? 'bg-indigo-600 animate-ping' : 'bg-slate-350'}`} />
          <span className="text-[9px] font-mono font-bold tracking-wider uppercase text-slate-400">
            {isSpeaking ? 'Voicing Soundwave...' : 'Voice Synthesizer Ready'}
          </span>
        </div>

        <div className="flex flex-col items-center gap-3">
          <div className={`p-4 rounded-full transition-all duration-300 ${isSpeaking ? 'bg-indigo-600 text-white animate-pulse shadow-md' : 'bg-white border border-slate-200 text-slate-500 shadow-2xs'}`}>
            <Volume2 size={36} />
          </div>
          <div>
            <span className="text-[10px] font-mono font-extrabold text-indigo-700 tracking-widest uppercase block mb-1">
              🗣️ PRIMARY COGNITIVE SPEECH TRANSLATION CHANNEL
            </span>
            <div id="stable-emitted-box" className="text-4xl sm:text-5xl font-black font-mono tracking-widest text-indigo-850 min-h-[50px] flex items-center justify-center">
              {stableText ? stableText.toUpperCase() : <span className="text-slate-350 font-sans tracking-normal text-lg font-medium">Awaiting stability consensus...</span>}
            </div>
            <p className="text-xs text-slate-400 mt-2">
              Verbal outloud synthesized automatically under active cadence speed of <strong>0.85x</strong>
            </p>
          </div>
        </div>

        {/* Dynamic Speech Waveform Animation (when active) */}
        <div className="flex items-center gap-1.5 mt-4 min-h-[20px]">
          {[1,2,3,4,5,6,7,8,9,10].map((item) => {
            return (
              <span 
                key={`wave-${item}`} 
                className={`w-1 bg-indigo-500 rounded-full transition-all duration-300`}
                style={{
                  height: isSpeaking ? `${Math.floor(Math.random() * 24) + 6}px` : '4px',
                  opacity: isSpeaking ? '1' : '0.2',
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Grid: Secondary analytics - raw tracker and parameters split */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Instant Raw Frame Decoder (Demoted to secondary monitor panel) */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col justify-between min-h-[90px] text-left">
          <div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono text-slate-500 font-bold uppercase tracking-wider">Raw YOLO Frame Detector</span>
              {flickerActive && (
                <span className="text-[9px] font-mono text-red-600 animate-pulse bg-red-50 px-1 py-0.5 rounded border border-red-200">
                  ⚡ Camera Noise
                </span>
              )}
            </div>
            <div id="frame-decoded-box" className="text-2xl font-bold font-mono tracking-widest text-slate-800 mt-2 select-all h-8 leading-8">
              {currentFrameText ? currentFrameText.toUpperCase() : <span className="text-slate-400 text-sm tracking-normal">No boxes in camera bounds</span>}
            </div>
          </div>
          <span className="text-[9px] text-slate-400 mt-1 block">YOLO coordinates output, dynamically sorted with no temporal stability filter</span>
        </div>

        {/* Pipeline Trigger Mode Switcher */}
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg flex flex-col justify-between min-h-[90px] text-left">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-mono text-slate-500 font-bold uppercase tracking-wider">Speech Trigger Mode Selector</span>
            <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border font-bold ${
              pipelineMode === 'continuous'
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-amber-50 border-amber-200 text-amber-700'
            }`}>
              {pipelineMode === 'continuous' ? 'Auto-Voice Outloud' : 'Manual Trigger mode'}
            </span>
          </div>

          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center gap-2">
              <button
                id="btn-toggle-pipeline-mode"
                onClick={onTogglePipelineMode}
                className="text-slate-400 hover:text-slate-600 transition-colors inline-flex cursor-pointer"
                title="Toggle continuous text outloud"
              >
                {pipelineMode === 'continuous' ? (
                  <ToggleRight size={28} className="text-indigo-600" />
                ) : (
                  <ToggleLeft size={28} className="text-slate-400" />
                )}
              </button>
              <span className="text-xs text-slate-700 font-semibold">
                {pipelineMode === 'continuous' ? 'Accumulate & Auto-Speak' : 'Press bar to speak outloud'}
              </span>
            </div>

            {pipelineMode === 'continuous' ? (
              <span className="text-[10px] font-bold text-slate-500 max-w-[140px] text-right block leading-tight">
                Requires <strong>{config.smoothingWindow}</strong> matching frames
              </span>
            ) : (
              <button
                id="btn-manual-speech-trigger"
                onClick={handleTriggerManualSpeech}
                disabled={!currentFrameText}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-all ${
                  currentFrameText
                    ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-2xs'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Volume2 size={12} />
                Read (Spacebar)
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mode Switches */}
      <div className="flex flex-col sm:flex-row justify-between items-center bg-slate-50 border border-slate-250 p-3 rounded-lg gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-700 font-bold uppercase tracking-wider text-left">Verify Speakers Cadence Output:</span>
        </div>

        <div className="flex items-center gap-2 justify-end w-full sm:w-auto">
          <button
            id="btn-test-sample-vocal"
            onClick={() => onSpeak(stableText || "Active vocal preference system operational")}
            className="px-3.5 py-1.5 text-xs font-bold bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-lg hover:bg-indigo-100 cursor-pointer transition-all"
          >
            🔊 Sample Verbalizer Check
          </button>
          
          <button
            id="btn-reset-history"
            onClick={handleResetHistory}
            className="px-2.5 py-1.5 text-[11px] font-bold bg-slate-200 border border-slate-300 hover:bg-slate-300 text-slate-700 rounded-lg cursor-pointer transition-all"
          >
            Clear Buffers
          </button>
        </div>
      </div>

      {/* Collapsible Slide Parameters Section */}
      <div className="space-y-4 pt-2 border-t border-slate-200">
        <button
          onClick={() => setShowTuningOptions(!showTuningOptions)}
          className="flex items-center justify-between w-full py-1 text-xs font-bold text-slate-700 hover:text-indigo-700 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-1.5 font-mono tracking-wide">
            <Sliders size={13} className={showTuningOptions ? "text-indigo-600" : "text-slate-400"} />
            <span>Advanced Calibration Parameters</span>
          </div>
          <span className="text-[10px] bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded text-slate-600 border border-slate-250">
            {showTuningOptions ? "Hide settings" : "Configure sliders & filters ⚙️"}
          </span>
        </button>

        {showTuningOptions && (
          <div className="space-y-4 pt-2 animate-feed-in">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Tolerance Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-655 font-semibold">Row Y-Tolerance:</span>
                  <strong className="font-mono text-amber-700">{config.rowToleranceRatio.toFixed(2)}x</strong>
                </div>
                <input
                  id="slider-tolerance"
                  type="range"
                  min="0.2"
                  max="1.2"
                  step="0.05"
                  value={config.rowToleranceRatio}
                  onChange={(e) =>
                    onChangeConfig({ ...config, rowToleranceRatio: parseFloat(e.target.value) })
                  }
                  className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg border-none focus:outline-none"
                />
                <span className="text-[9px] text-slate-455 block">Relative multiplier of cell heights for row bin cuts</span>
              </div>

              {/* Space Width Ratio Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-655 font-semibold">Space Width Ratio:</span>
                  <strong className="font-mono text-emerald-700">{config.spaceWidthRatio.toFixed(1)}x</strong>
                </div>
                <input
                  id="slider-space-width-ratio"
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.1"
                  value={config.spaceWidthRatio}
                  onChange={(e) =>
                    onChangeConfig({ ...config, spaceWidthRatio: parseFloat(e.target.value) })
                  }
                  className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg border-none focus:outline-none"
                />
                <span className="text-[9px] text-slate-455 block">Gap threshold (relative to box width) to insert spaces</span>
              </div>

              {/* Buffer Length Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-655 font-semibold">Buffer Consensuses:</span>
                  <strong className="font-mono text-sky-700">{config.smoothingWindow} Frames</strong>
                </div>
                <input
                  id="slider-buffer-window"
                  type="range"
                  min="2"
                  max="15"
                  step="1"
                  value={config.smoothingWindow}
                  onChange={(e) =>
                    onChangeConfig({ ...config, smoothingWindow: parseInt(e.target.value) })
                  }
                  className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg border-none focus:outline-none"
                />
                <span className="text-[9px] text-slate-455 block">Consecutive frames required for speech validation</span>
              </div>

              {/* Camera Noise Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-655 font-semibold">Virtual Camera Noise:</span>
                  <strong className="font-mono text-red-600">{config.noiseChance}%</strong>
                </div>
                <input
                  id="slider-noise-chance"
                  type="range"
                  min="0"
                  max="50"
                  step="2"
                  value={config.noiseChance}
                  onChange={(e) =>
                    onChangeConfig({ ...config, noiseChance: parseInt(e.target.value) })
                  }
                  className="w-full accent-red-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg border-none focus:outline-none"
                />
                <span className="text-[9px] text-slate-455 block">Chance of character dropout or mutation on frame ticks</span>
              </div>
            </div>

            {/* Real-world hardware and pipeline integrations info widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* CLAHE preprocessing control */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-lg gap-4">
                <div className="flex items-center gap-2.5 text-left">
                  <div className={`p-2 rounded transition-all ${config.claheEnabled ? 'bg-indigo-550 text-white' : 'bg-slate-205 text-slate-400'}`}>
                    <Eye size={14} />
                  </div>
                  <div className="text-left">
                    <span className="text-xs font-semibold text-slate-800 block">CLAHE Shadow-Enhance Filter</span>
                    <span className="text-[10px] text-slate-500 block">Maximizes dot lighting shadows for reliable CV tracking</span>
                  </div>
                </div>
                <button
                  id="btn-toggle-clahe"
                  onClick={() => onChangeConfig({ ...config, claheEnabled: !config.claheEnabled })}
                  className="text-slate-400 hover:text-slate-600 transition-opacity inline-flex cursor-pointer shrink-0"
                >
                  {config.claheEnabled ? (
                    <ToggleRight size={28} className="text-emerald-600" />
                  ) : (
                    <ToggleLeft size={28} className="text-slate-400" />
                  )}
                </button>
              </div>

              {/* Diagnostic dump panel */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-lg gap-4">
                <div className="flex items-center gap-2.5 text-left">
                  <div className="p-2 bg-slate-205 text-slate-600 border border-slate-300 rounded">
                    <Save size={14} />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-800 block">Local Diagnostic Bundle</span>
                    <span className="text-[10px] text-slate-500 block font-medium">Logs raw detections, CLAHE thresholds, and spatial order</span>
                  </div>
                </div>
                <button
                  id="btn-diagnostic-dump"
                  onClick={handleSaveDiagnosticLog}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 hover:border-slate-400 text-slate-700 font-bold font-mono text-xs rounded-lg transition-all cursor-pointer select-none shadow-2xs"
                >
                  Dump Logs (S)
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Frame Queue visualizer bar */}
      {isSimulatingFeed && (
        <div className="space-y-2 mt-1">
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">
            Rolling Frame Accumulator Buffer (Queue size: {frameHistory.length}/{config.smoothingWindow})
          </span>
          <div className="flex gap-1 overflow-x-auto pb-1 min-h-[36px]">
            {frameHistory.map((frame, index) => {
              const isMatch = frame === frameHistory[frameHistory.length - 1];
              return (
                <div
                  key={`frame-idx-${index}`}
                  className={`flex-shrink-0 px-2 py-1 rounded text-[10px] font-mono tracking-widest border transition-all flex flex-col justify-center items-center font-bold min-w-[70px] ${
                    isMatch
                      ? 'bg-sky-50 border-sky-200 text-sky-700'
                      : 'bg-red-50 border-red-200 text-red-655'
                  }`}
                >
                  <span className="text-[8px] text-slate-400 font-normal">t - {frameHistory.length - 1 - index}</span>
                  <span className="truncate max-w-[65px]">{frame ? frame.toUpperCase() : 'EMPTY'}</span>
                </div>
              );
            })}
            {frameHistory.length === 0 && (
              <span className="text-slate-405 text-xs py-1">Continuous pipe buffer empty...</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
