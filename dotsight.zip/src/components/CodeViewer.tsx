/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Copy, Check, Download, BookOpen, Terminal, Code, Cpu } from 'lucide-react';

interface CodeViewerProps {
  pythonCode: string;
}

export default function CodeViewer({ pythonCode }: CodeViewerProps) {
  const [activeTab, setActiveTab] = useState<'script' | 'setup' | 'math'>('script');
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([pythonCode], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = 'braille_translator.py';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div id="code-viewer-container" className="flex flex-col h-full bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      {/* Tab Navigation Headers */}
      <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-3 gap-1">
        <button
          id="tab-btn-script"
          onClick={() => setActiveTab('script')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all duration-200 ${
            activeTab === 'script'
              ? 'bg-white text-sky-600 border-t-2 border-sky-500 font-bold'
              : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Code size={14} />
          braille_translator.py
        </button>
        <button
          id="tab-btn-setup"
          onClick={() => setActiveTab('setup')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all duration-200 ${
            activeTab === 'setup'
              ? 'bg-white text-emerald-700 border-t-2 border-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Terminal size={14} />
          Local Setup Guide
        </button>
        <button
          id="tab-btn-math"
          onClick={() => setActiveTab('math')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all duration-200 ${
            activeTab === 'math'
              ? 'bg-white text-amber-700 border-t-2 border-amber-600 font-bold'
              : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Cpu size={14} />
          Sorting Mathematics
        </button>
      </div>

      {/* Tab Contents Area */}
      <div className="flex-1 overflow-y-auto p-5 text-slate-800">
        {activeTab === 'script' && (
          <div className="flex flex-col h-full space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div className="text-left">
                <h3 className="text-sm font-bold text-slate-800">Production-Ready Python Script</h3>
                <p className="text-xs text-slate-500 mt-1">Deploy locally with your custom-trained YOLO weights</p>
              </div>
              <div className="flex gap-2">
                <button
                  id="btn-copy-code"
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md bg-slate-100 border border-slate-200 hover:bg-slate-200 text-slate-700 transition-all cursor-pointer"
                >
                  {copied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  {copied ? 'Copied!' : 'Copy Script'}
                </button>
                <button
                  id="btn-download-code"
                  onClick={handleDownload}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md bg-sky-600 hover:bg-sky-500 text-white transition-all cursor-pointer"
                >
                  <Download size={14} />
                  Download .py
                </button>
              </div>
            </div>

            {/* Code container */}
            <div className="relative flex-1 bg-slate-50 border border-slate-200 rounded-lg p-4 font-mono text-xs text-slate-850 overflow-x-auto max-h-[500px] text-left">
              <pre className="whitespace-pre">{pythonCode}</pre>
            </div>
          </div>
        )}

        {activeTab === 'setup' && (
          <div className="space-y-6 text-sm text-slate-700 leading-relaxed text-left">
            <div>
              <h3 className="text-base font-bold text-emerald-700 flex items-center gap-2 mb-2">
                <Terminal size={18} />
                Local Environment Initialization
              </h3>
              <p className="text-xs text-slate-500">Follow these steps on your computer to deploy the real-time translating camera setup.</p>
            </div>

            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">1. Install Dependencies</h4>
                <div className="bg-slate-100 border border-slate-200 p-3 rounded-md font-mono text-xs text-emerald-800 font-bold">
                  pip install opencv-python ultralytics pyttsx3
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">2. Prepare Bounding Box Classes</h4>
                <p className="text-xs text-slate-500 mb-2">
                  Your custom trained YOLO model should align class IDs with English letters (typically 26 indices map directly to a-z):
                </p>
                <div className="bg-slate-100 border border-slate-200 p-3 rounded-md font-mono text-xs text-slate-650">
                  <span className="text-emerald-700 font-bold">class_id: label</span>
                  <br />0: a, 1: b, 2: c, ..., 25: z
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">3. Command Line Execution</h4>
                <p className="text-xs text-slate-500 mb-2">Run the script passing your trained model file (.pt format) through the CLI args:</p>
                <div className="bg-slate-100 border border-slate-200 p-3 rounded-md font-mono text-xs text-sky-700 font-bold">
                  python braille_translator.py --weights weights/best.pt --conf 0.55 --buffer 8
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">4. Pipeline Shortcuts (Local GUI Window)</h4>
                <ul className="list-disc pl-5 text-xs text-slate-600 space-y-1.5">
                  <li><strong className="text-slate-905">[Q]</strong> - Destroys cv2 frame loops and halts speech thread servers safely.</li>
                  <li><strong className="text-slate-905">[Spacebar]</strong> - Translates and triggers TTS pronunciations when operating in Manual Trigger Mode.</li>
                  <li><strong className="text-slate-905">[M]</strong> - Hot-swap dynamically between Continuous Stream mode and Manual mode.</li>
                  <li><strong className="text-slate-905">[R]</strong> - Hard-resets accumulation sliding statistics.</li>
                </ul>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-900 text-xs">
                <strong>💡 Windows & Mac Speech Sync Note:</strong>
                <p className="mt-1 leading-relaxed text-amber-850">
                  Using offline Text-to-Speech (<span className="font-mono bg-amber-100/50 px-1 rounded">pyttsx3</span>) requires initializing the sub-framework on the dedicated thread taking care of verbalizations. If Windows complains about COM ports during setup, our threaded executor already handles isolation elegantly!
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'math' && (
          <div className="space-y-6 text-sm text-slate-750 leading-relaxed text-left">
            <div>
              <h3 className="text-base font-bold text-amber-700 flex items-center gap-2 mb-2">
                <Cpu size={18} />
                Spatial Sorting & Line Clustering Mathematics
              </h3>
              <p className="text-xs text-slate-550 font-medium">Analyzing the coordinate-grouping math behind physical text recognition</p>
            </div>

            <div className="space-y-4 text-xs text-slate-600">
              <p className="leading-relaxed">
                When a camera snaps Braille cells, YOLO processes the entire frame layout at once. It outputs bounding coordinates (xmin, ymin, xmax, ymax) in erratic list orders that correspond to model confidence levels rather than reading sequences.
              </p>

              <div>
                <h4 className="font-bold text-emerald-800 text-xs uppercase tracking-wider mb-1.5">Algorithm Step 1: Centroid Identification</h4>
                <p className="mb-2">We discard raw coordinate points and derive the strict absolute center points for each cell bounding box:</p>
                <div className="bg-slate-100 border border-slate-200 p-3 rounded font-mono text-center text-amber-800 font-bold">
                  Y_center = (y_min + y_max) / 2.0 <br />
                  X_center = (x_min + x_max) / 2.0
                </div>
              </div>

              <div>
                <h4 className="font-bold text-emerald-800 text-xs uppercase tracking-wider mb-1.5">Algorithm Step 2: Sorting Top-To-Bottom</h4>
                <p className="leading-relaxed">We perform an initial global sort prioritized purely by the Y_center coordinate. This clusters upper lines before lower rows, regardless of their leftward/rightward distribution.</p>
              </div>

              <div>
                <h4 className="font-bold text-emerald-800 text-xs uppercase tracking-wider mb-1.5">Algorithm Step 3: Segment-Row Binning (Adaptive Thresholding)</h4>
                <p className="mb-2 leading-relaxed">
                  To group boxes into a designated <i>row</i> (e.g., when letters fluctuate slightly vertically due to paper curling or slanted camera setup), we define a pixel sorting tolerance. Instead of using a static pixel amount (like &quot;50px&quot;), which breaks when the camera changes zoom, we calculate a dynamic reference:
                </p>
                <div className="bg-slate-100 border border-slate-200 p-3 rounded font-mono text-center text-slate-700 font-semibold">
                  Avg_Cell_Height = Sum(y_max - y_min) / Cell_Count <br />
                  Y_Tolerance = Avg_Cell_Height × Tolerance_Ratio
                </div>
                <p className="mt-2 leading-relaxed">
                  As we iterate through the Y-sorted array, we check if the delta Y between adjacent cells is within <code className="text-amber-800 font-semibold font-mono">Y_Tolerance</code>. If so, they share the same reading line! If not, a line-break is registered.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-emerald-800 text-xs uppercase tracking-wider mb-1.5">Algorithm Step 4: Horizontal Realignment</h4>
                <p className="leading-relaxed">
                  Once individual rows are partitioned, we sort each row group independently from <strong>Left to Right</strong> based on their <code className="text-sky-800 font-mono font-semibold">X_center</code> coordinates. Flattening these sorted groups yields the exact English spelling as intended by the physical author!
                </p>
              </div>

              <div className="border-t border-slate-200 pt-4">
                <span className="text-slate-800 font-bold block mb-2 font-mono text-left">Simulated Row Tolerance Effects:</span>
                <div className="grid grid-cols-2 gap-3 text-[11px]">
                  <div className="p-3 border border-sky-100 rounded bg-sky-50 text-left">
                    <strong className="text-sky-850 font-bold text-xs">Too Low (e.g. &lt; 0.2):</strong>
                    <p className="mt-1 leading-relaxed text-slate-600">Normal single words read like &quot;H&quot;, then &quot;E&quot;, then &quot;L&quot; individually as different rows because tiny vertical vibrations are flagged as line cuts.</p>
                  </div>
                  <div className="p-3 border border-amber-200 rounded bg-amber-50 text-left">
                    <strong className="text-amber-850 font-bold text-xs">Too High (e.g. &gt; 1.3):</strong>
                    <p className="mt-1 leading-relaxed text-slate-600">Multiple separate rows merge into one line, reading &quot;H W E O L R L L D O&quot; instead of splitting &quot;hello&quot; and &quot;world&quot; properly.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
