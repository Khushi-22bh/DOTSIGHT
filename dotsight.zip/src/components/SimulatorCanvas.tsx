/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Play, RotateCcw, Plus, Trash2, Sliders, Layers, RefreshCw } from 'lucide-react';
import { BrailleCell, BoundingRow } from '../types';

interface SimulatorCanvasProps {
  cells: BrailleCell[];
  sortedCells: BrailleCell[];
  boundingRows: BoundingRow[];
  config: {
    rowToleranceRatio: number;
    spaceWidthRatio: number;
    claheEnabled: boolean;
  };
  onUpdateCells: (newCells: BrailleCell[]) => void;
  onClearCells: () => void;
}

export default function SimulatorCanvas({
  cells,
  sortedCells,
  boundingRows,
  config,
  onUpdateCells,
  onClearCells
}: SimulatorCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Track currently selected cell
  const [selectedCellId, setSelectedCellId] = useState<string | null>(null);
  const [showToleranceBands, setShowToleranceBands] = useState<boolean>(true);
  const [showReadingPath, setShowReadingPath] = useState<boolean>(true);
  
  // New cell parameters in form
  const [newLetter, setNewLetter] = useState<string>('a');
  
  // Dragging states
  const [draggedCellId, setDraggedCellId] = useState<string | null>(null);
  const [dragStartCoords, setDragStartCoords] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [dragStartCellPos, setDragStartCellPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Handle click on canvas background to deselect or add
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget || (e.target as HTMLElement).id === 'grid-background') {
      setSelectedCellId(null);
    }
  };

  // Convert client screen mouse coordinates to virtual viewBox space (800x400)
  const getVirtualCoords = (clientX: number, clientY: number) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 800;
    const y = ((clientY - rect.top) / rect.height) * 400;
    return { x: Math.round(x), y: Math.round(y) };
  };

  // Handle Mousdown on individual cell
  const handleCellMouseDown = (e: React.MouseEvent | React.TouchEvent, cell: BrailleCell) => {
    e.stopPropagation();
    setSelectedCellId(cell.id);
    setDraggedCellId(cell.id);

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    setDragStartCoords({ x: clientX, y: clientY });
    setDragStartCellPos({ x: cell.x, y: cell.y });
  };

  // Handle Mousemove in global scope during drag
  useEffect(() => {
    const handleGlobalMove = (e: MouseEvent | TouchEvent) => {
      if (!draggedCellId) return;

      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const deltaX = clientX - dragStartCoords.x;
      const deltaY = clientY - dragStartCoords.y;

      // Scale speed from pixels to 800x400 coordinate space
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const scaleX = 800 / rect.width;
      const scaleY = 400 / rect.height;

      const newX = dragStartCellPos.x + deltaX * scaleX;
      const newY = dragStartCellPos.y + deltaY * scaleY;

      // Clamp values so bboxes don't fall off screen margin bounds
      const clampedX = Math.max(10, Math.min(800 - 60, newX));
      const clampedY = Math.max(10, Math.min(400 - 75, newY));

      onUpdateCells(
        cells.map((c) => (c.id === draggedCellId ? { ...c, x: Math.round(clampedX), y: Math.round(clampedY) } : c))
      );
    };

    const handleGlobalUp = () => {
      setDraggedCellId(null);
    };

    if (draggedCellId) {
      window.addEventListener('mousemove', handleGlobalMove);
      window.addEventListener('mouseup', handleGlobalUp);
      window.addEventListener('touchmove', handleGlobalMove, { passive: false });
      window.addEventListener('touchend', handleGlobalUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleGlobalMove);
      window.removeEventListener('mouseup', handleGlobalUp);
      window.removeEventListener('touchmove', handleGlobalMove);
      window.removeEventListener('touchend', handleGlobalUp);
    };
  }, [draggedCellId, dragStartCoords, dragStartCellPos, cells, onUpdateCells]);

  // Remove Cell trigger
  const handleRemoveCell = (id: string) => {
    onUpdateCells(cells.filter((c) => c.id !== id));
    if (selectedCellId === id) {
      setSelectedCellId(null);
    }
  };

  // Add cell in center of viewport
  const handleAddCell = () => {
    const letter = newLetter.trim().toLowerCase().slice(0, 1);
    if (!letter || !/^[a-z]$/.test(letter)) return;

    // Place at slightly random center offset to prevent stacking
    const randomOffset = Math.floor(Math.random() * 60) - 30;
    const newCell: BrailleCell = {
      id: `cell-${Date.now()}`,
      x: 375 + randomOffset,
      y: 175 + randomOffset,
      width: 45,
      height: 60,
      letter
    };

    onUpdateCells([...cells, newCell]);
    setSelectedCellId(newCell.id);
  };

  // Quick edit character
  const handleChangeLetter = (id: string, letter: string) => {
    const cleanLetter = letter.toLowerCase().trim().slice(0, 1);
    onUpdateCells(
      cells.map((c) => (c.id === id ? { ...c, letter: cleanLetter } : c))
    );
  };

  return (
    <div id="simulator-canvas-section" className="flex flex-col bg-white border border-slate-200 rounded-xl p-5 shadow-xs gap-4 text-left">
      
      {/* Simulation Controls & Flags */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-800 uppercase tracking-widest flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            Webcam Feed Simulation
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Drag cells around or modify coordinates to test Y-Clustering live</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Group Toggles */}
          <button
            id="toggle-tolerance-bands"
            onClick={() => setShowToleranceBands(!showToleranceBands)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-bold tracking-wide border cursor-pointer transition-all ${
              showToleranceBands
                ? 'bg-amber-100/80 border-amber-300 text-amber-800 shadow-2xs'
                : 'bg-transparent border-slate-200 text-slate-600 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Layers size={12} />
            {showToleranceBands ? 'Hide Y-Bands' : 'Show Y-Bands'}
          </button>
          
          <button
            id="toggle-reading-path"
            onClick={() => setShowReadingPath(!showReadingPath)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[11px] font-bold tracking-wide border cursor-pointer transition-all ${
              showReadingPath
                ? 'bg-sky-100/80 border-sky-300 text-sky-800 shadow-2xs'
                : 'bg-transparent border-slate-200 text-slate-600 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Sliders size={12} />
            {showReadingPath ? 'Hide Paths' : 'Show Paths'}
          </button>

          <button
            id="btn-clear-sandbox"
            onClick={onClearCells}
            className="flex items-center gap-1 px-2 py-1.5 rounded text-[11px] font-bold bg-red-50 border border-red-200 text-red-655 hover:bg-red-100 transition-all cursor-pointer"
            title="Remove all detections"
          >
            <Trash2 size={12} />
            Reset Feed
          </button>
        </div>
      </div>

      {/* Main Virtual Interactive Camera viewport */}
      <div
        id="camera-view-container"
        ref={containerRef}
        onClick={handleCanvasClick}
        className={`relative aspect-[2/1] w-full border-2 rounded-lg overflow-hidden select-none transition-all duration-300 ${
          config.claheEnabled
            ? 'bg-slate-800 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.2)]'
            : 'bg-slate-100/90 border-slate-200 shadow-inner'
        }`}
        style={{ touchAction: 'none' }}
      >
        {config.claheEnabled && (
          <div className="absolute top-3 left-12 bg-indigo-600 text-white px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider z-25 shadow animate-pulse">
            CLAHE Shadow Enhancer Active
          </div>
        )}
        {/* Optical HUD details */}
        <div id="grid-background" className="absolute inset-0 bg-[linear-gradient(rgba(148,163,184,0.15)_1px,transparent_1px),linear-gradient(90deg,rgba(148,163,184,0.15)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
        
        {/* Corner lens bounds styling */}
        <div className="absolute top-3 left-3 w-5 h-5 border-t border-l border-slate-400 pointer-events-none" />
        <div className="absolute top-3 right-3 w-5 h-5 border-t border-r border-slate-400 pointer-events-none" />
        <div className="absolute bottom-3 left-3 w-5 h-5 border-b border-l border-slate-400 pointer-events-none" />
        <div className="absolute bottom-3 right-3 w-5 h-5 border-b border-r border-slate-400 pointer-events-none" />
        
        {/* Animated Scanning horizontal line laser */}
        <div className="absolute left-0 right-0 h-[1.5px] bg-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.5)] animate-[bounce_8s_infinite] pointer-events-none" />

        {/* Dynamic Translucent Horizontal Bounding Tolerance Channels */}
        {showToleranceBands && boundingRows.map((row, rIdx) => {
          // Find standard height offset
          const top = row.yCenterStart;
          const bottom = row.yCenterEnd;
          const height = Math.max(30, bottom - top);
          const blockPercentageTop = (top / 400) * 100;
          const blockPercentageHeight = (height / 400) * 100;

          return (
            <div
              key={`band-${rIdx}`}
              className="absolute left-0 right-0 bg-amber-500/5 border-y border-dashed border-amber-400/30 pointer-events-none flex items-center pl-4 transition-all animate-fade-in"
              style={{
                top: `${blockPercentageTop}%`,
                height: `${blockPercentageHeight}%`
              }}
            >
              <span className="text-[9px] font-mono font-bold text-amber-600/60 uppercase select-none tracking-widest">
                Row #{rIdx + 1} Cluster (H: {Math.round(height)}px)
              </span>
            </div>
          );
        })}

        {/* Vector SVG: Line connections mapping reading sequence */}
        {showReadingPath && sortedCells.length > 1 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 800 400">
            <defs>
              <marker
                id="marker-arrow"
                viewBox="0 0 10 10"
                refX="28" // Offset from coordinates center of bboxes
                refY="5"
                markerWidth="5"
                markerHeight="5"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#0284c7" />
              </marker>
            </defs>
            {sortedCells.map((cell, i) => {
              if (i === sortedCells.length - 1) return null;
              const nextCell = sortedCells[i + 1];
              const fromX = cell.x + cell.width / 2;
              const fromY = cell.y + cell.height / 2;
              const toX = nextCell.x + nextCell.width / 2;
              const toY = nextCell.y + nextCell.height / 2;

              return (
                <g key={`path-${cell.id}-${nextCell.id}`}>
                  {/* Subtle trace arrow line */}
                  <line
                    x1={fromX}
                    y1={fromY}
                    x2={toX}
                    y2={toY}
                    stroke="#0284c7"
                    strokeWidth="1.5"
                    strokeDasharray="4 3"
                    className="animate-[dash_10s_linear_infinite]"
                    markerEnd="url(#marker-arrow)"
                  />
                  {/* Glow backdrop for path */}
                  <line
                    x1={fromX}
                    y1={fromY}
                    x2={toX}
                    y2={toY}
                    stroke="#38bdf8"
                    strokeWidth="3.5"
                    strokeOpacity="0.1"
                  />
                </g>
              );
            })}
          </svg>
        )}

        {/* Coordinates grid / boxes */}
        <div className="absolute inset-0 w-full h-full" style={{ position: 'relative' }}>
          {cells.map((cell) => {
            const sortedIndex = sortedCells.findIndex((c) => c.id === cell.id);
            const isSelected = selectedCellId === cell.id;
            
            // Map 800x400 viewbox units into physical percents inside container
            const pLeft = (cell.x / 800) * 100;
            const pTop = (cell.y / 400) * 100;
            const pWidth = (cell.width / 800) * 100;
            const pHeight = (cell.height / 400) * 100;

            return (
              <div
                key={cell.id}
                onMouseDown={(e) => handleCellMouseDown(e, cell)}
                onTouchStart={(e) => handleCellMouseDown(e, cell)}
                className={`absolute rounded-md cursor-grab active:cursor-grabbing select-none transition-shadow z-20 ${
                  isSelected
                    ? 'border-2 border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                    : 'border border-sky-500/80 hover:border-sky-600 hover:shadow-[0_0_8px_rgba(14,165,233,0.15)] bg-sky-50/10'
                }`}
                style={{
                  left: `${pLeft}%`,
                  top: `${pTop}%`,
                  width: `${pWidth}%`,
                  height: `${pHeight}%`,
                  backgroundColor: isSelected ? 'rgba(16,185,129,0.06)' : 'rgba(14,165,233,0.03)'
                }}
              >
                {/* YOLO Bounding Box HUD elements */}
                <div className={`absolute top-0 left-0 -translate-y-full px-1 py-0.5 rounded-t text-[9px] font-mono font-bold select-none text-white flex items-center gap-1 ${
                  isSelected ? 'bg-emerald-600' : 'bg-sky-650'
                }`}>
                  <span>{cell.letter.toUpperCase()}</span>
                  <span className="text-[7.5px] text-gray-200">
                    #{sortedIndex !== -1 ? sortedIndex + 1 : '?'}
                  </span>
                </div>

                {/* Draw tactile dots pattern (simulating physical Braille on high zooms) */}
                <div className={`grid grid-cols-2 grid-rows-3 h-full px-2 py-1.5 gap-1 place-items-center transition-all ${
                  config.claheEnabled ? 'opacity-85 scale-110' : 'opacity-40'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                  <span className={`w-1.5 h-1.5 rounded-full transition-all ${config.claheEnabled ? 'bg-black shadow-[0_0_3px_black]' : 'bg-sky-700'}`} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Under-canvas controls: add or edit parameters */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        {/* Spawn New Box */}
        <div className="md:col-span-6 flex gap-2 items-center bg-slate-50 border border-slate-200 p-3 rounded-lg text-left">
          <span className="text-xs text-slate-700 font-bold uppercase tracking-wider block whitespace-nowrap">Add Detection:</span>
          <div className="flex gap-2 flex-1">
            <select
              id="select-new-letter"
              value={newLetter}
              onChange={(e) => setNewLetter(e.target.value)}
              className="bg-white border border-slate-300 rounded text-xs px-2.5 py-1.5 font-mono font-bold text-sky-700 focus:outline-none focus:border-sky-500"
            >
              {'abcdefghijklmnopqrstuvwxyz'.split('').map((char) => (
                <option key={char} value={char}>
                  letter: {char.toUpperCase()}
                </option>
              ))}
            </select>
            <button
              id="btn-add-cell"
              onClick={handleAddCell}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-lg transition-all cursor-pointer shadow-2xs"
            >
              <Plus size={14} />
              Inject BBox
            </button>
          </div>
        </div>

        {/* Selected Cell Parameters Card */}
        <div className="md:col-span-6">
          {selectedCellId ? (
            (() => {
              const selectedCell = cells.find((c) => c.id === selectedCellId);
              if (!selectedCell) return null;

              return (
                <div id="inspector-card" className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-left shadow-2xs">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-emerald-805 font-mono uppercase">BOX SELECTED</span>
                    <input
                      id="input-inspect-letter"
                      type="text"
                      maxLength={1}
                      value={selectedCell.letter}
                      onChange={(e) => handleChangeLetter(selectedCell.id, e.target.value)}
                      className="w-10 bg-white border border-emerald-300 rounded py-0.5 px-1 font-mono text-center text-xs font-bold text-emerald-700 focus:outline-none focus:border-emerald-500"
                    />
                    <span className="text-[10px] font-mono text-slate-500 font-medium">
                      X:{selectedCell.x}, Y:{selectedCell.y}
                    </span>
                  </div>
                  <button
                    id="btn-remove-selected"
                    onClick={() => handleRemoveCell(selectedCell.id)}
                    className="flex items-center gap-1 text-[11px] text-red-650 hover:text-red-750 px-2.5 py-1 rounded bg-red-50 border border-red-200 hover:bg-red-100 transition-colors cursor-pointer"
                  >
                    <Trash2 size={12} />
                    Delete
                  </button>
                </div>
              );
            })()
          ) : (
            <div className="flex items-center justify-center p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-400 font-medium text-center">
              Click a cell bounding box to inspect and manipulate coordinates
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
